#Testes funcionais (Playwright) - LocalEats

import re

from playwright.sync_api import Page, expect

URL = "https://local-eats-unisenac.vercel.app/"


# TF01
def test_pagina_inicial_e_navegacao_para_meus_pedidos(page: Page):
    page.goto(URL)

    # Assertion 1: apresentação da página inicial
    expect(
        page.get_by_role("heading", name="Descubra sabores incríveis na sua cidade")
    ).to_be_visible()

    # Assertion 2: categorias disponíveis
    for categoria in ["Todos", "Italiana", "Japonesa", "Brasileira", "Mexicana"]:
        expect(page.get_by_text(categoria, exact=True).first).to_be_visible()

    # Interação: navegar pelo menu
    page.get_by_role("link", name="Meus Pedidos").click()

    # Assertion 3: resultado observável da navegação
    expect(page).to_have_url(re.compile(r"orders\.html"))
