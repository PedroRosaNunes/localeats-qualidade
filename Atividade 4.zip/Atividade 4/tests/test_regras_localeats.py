#Testes unitários - Regra 2: desconto do pedido.
import pytest

from regras_localeats import calcular_desconto


# TU01
def test_desconto_zero_para_pedido_abaixo_de_100():
    assert calcular_desconto(99.99) == 0


# TU02
def test_desconto_de_10_porcento_para_pedido_a_partir_de_100():
    assert calcular_desconto(100) == pytest.approx(10.0)
    assert calcular_desconto(250) == pytest.approx(25.0)


# Diferencial: pytest.raises
def test_desconto_valor_negativo_gera_value_error():
    with pytest.raises(ValueError):
        calcular_desconto(-1)


# Diferencial: parametrize + casos de borda
@pytest.mark.parametrize(
    "valor, esperado",
    [(0, 0), (99.99, 0), (100, 10.0), (100.01, 10.001), (1000, 100.0)],
)
def test_desconto_casos_de_borda(valor, esperado):
    assert calcular_desconto(valor) == pytest.approx(esperado)
