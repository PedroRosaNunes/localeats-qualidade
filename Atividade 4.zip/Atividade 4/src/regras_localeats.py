"""Regras de negócio do LocalEats.

Responsável: [NOME COMPLETO]
Regra 2: desconto do pedido.
"""

VALOR_MINIMO_DESCONTO = 100.00
PERCENTUAL_DESCONTO = 0.10


def calcular_desconto(valor_pedido):
    """Retorna apenas o valor do desconto (10% para pedidos de R$ 100,00 ou mais)."""
    if valor_pedido < 0:
        raise ValueError("O valor do pedido não pode ser negativo.")
    if valor_pedido >= VALOR_MINIMO_DESCONTO:
        return valor_pedido * PERCENTUAL_DESCONTO
    return 0
