# Atividade 4: Testes Automatizados do LocalEats

## 1. Identificação
- **Turma:** Noturno
- **Modalidade:** Individual
- **Data da última execução:** [01/11/2026]
- **Integrantes:** Pedro Nunes

## 2. Integrantes e responsabilidades

| ID | Integrante responsável | Tipo | Comportamento verificado | Arquivo e função de teste |
|----|------------------------|------|--------------------------|---------------------------|
| TU01 | Pedro Nunes | Unitário | Pedido abaixo de R$ 100,00 não recebe desconto | tests/test_regras_localeats.py::test_desconto_zero_para_pedido_abaixo_de_100 |
| TU02 | Pedro Nunes | Unitário | Pedido de R$ 100,00 ou mais recebe 10% de desconto | tests/test_regras_localeats.py::test_desconto_de_10_porcento_para_pedido_a_partir_de_100 |
| TF01 | Pedro Nunes | Funcional | Apresentação da página inicial e navegação até "Meus Pedidos" | tests/test_localeats.py::test_pagina_inicial_e_navegacao_para_meus_pedidos |

## 3. Testes unitários

### Regra de Pedro Nunes
- **Regra escolhida:** Regra 2 – desconto do pedido
- **Função implementada:** `calcular_desconto(valor_pedido)`
- **Arquivo da implementação:** `src/regras_localeats.py`
- **Testes criados:** `teste de desconto zero para pedido abaixo de R$100,00`; `Pedido de R$ 100,00 ou mais recebe 10% de desconto`
- **Comportamentos verificados:** retorna 0 abaixo de R$ 100,00; retorna 10% do valor a partir de R$ 100,00 (apenas o valor do desconto); gera `ValueError` para valores negativos.

## 4. Aplicação do TDD

### TDD de Pedro Nunes
- **Regra escolhida:** Regra 2 – desconto do pedido
- **Primeiro teste escrito:** `teste de desconto zero para pedido abaixo de R$100,00`
- **Por que o teste falhou inicialmente:** a função `calcular_desconto` ainda não existia, então o import gerou erro (ImportError).
- **Implementação mínima realizada:** criei a função retornando `0`, suficiente para o primeiro teste passar.
- **Segundo teste escrito:** `test_desconto_de_10_porcento_para_pedido_a_partir_de_100`
- **Melhoria ou refatoração realizada:** o segundo teste falhou porque a função sempre retornava 0; adicionei a condição `valor >= 100` com o cálculo de 10%. Depois, extraí constantes (`VALOR_MINIMO_DESCONTO`, `PERCENTUAL_DESCONTO`) e adicionei a validação de valor negativo.

## 5. Testes funcionais com Playwright

Sistema: https://local-eats-unisenac.vercel.app/

### Teste funcional de Pedro Nunes
- **ID:** TF01
- **Fluxo automatizado:** apresentação da página inicial e navegação pelo menu.
- **Interação realizada:** clique no link "Meus Pedidos" do menu.
- **Primeira assertion:** o título "Descubra sabores incríveis na sua cidade" está visível.
- **Segunda assertion:** as categorias Todos, Italiana, Japonesa, Brasileira e Mexicana são exibidas (e, após o clique, a URL passa a conter `orders.html`).
- **Arquivo e função:** `tests/test_localeats.py::test_pagina_inicial_e_navegacao_para_meus_pedidos`
- **Resultado final:** Não aprovado

## 6. Resultado da execução

```powershell
python -m pytest -v | Tee-Object -FilePath relatorio-pytest.txt
```

- **Quantidade total de testes:** 4
- **Testes aprovados:** de todos feitos, nenhum passou para entrar no site, mas os testes unitatios funcionaram
- **Testes reprovados:** 4, todos falharam para entrar no site
- **Link para o relatório:** (relatorio-pytest.txt)
- **Observações:** Todos os testes não conseguiram entrar no site

## 7. Explicações individuais

### Explicação do teste de Pedro Nunes
- **Teste escolhido:** `teste de desconto de 10% para pedidos a partir de R$100,00`
- **Comportamento verificado:** pedidos de R$ 100,00 ou mais recebem 10% de desconto.
- **Dados ou estado inicial:** valores de pedido 100 e 250, sem estado prévio.
- **Resultado esperado:** descontos de 10,0 e 25,0.
- **O que faria o teste falhar:** a função retornar 0 para esses valores, usar `> 100` em vez de `>= 100` (o 100 falharia), usar percentual diferente de 10% ou retornar o valor final em vez do desconto.

## 8. Uso de inteligência artificial
- **Ferramenta utilizada:** Claude
- **Como a ferramenta foi utilizada:** Ajudar na organização do trabalho
- **Como o código sugerido foi verificado:** Foi verificado se não foi deixado nada de errado, como algum item que podesse estar faltando.

## 9. Diferenciais opcionais
- [x] Terceiro teste unitário para caso de borda (`test_desconto_casos_de_borda`)
- [x] Uso de `pytest.raises` (`test_desconto_valor_negativo_gera_value_error`)
- [x] Parametrização com `pytest.mark.parametrize` (`test_desconto_casos_de_borda`)

Arquivos: `tests/test_regras_localeats.py`
